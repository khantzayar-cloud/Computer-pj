const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  // Send a request to the server to login
  console.log(`Login request sent with username: ${username} and password: ${password}`);
});

registerForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  // Send a request to the server to register
  console.log(`Register request sent with username: ${username}, email: ${email}, password: ${password}, and confirm password: ${confirmPassword}`);
});